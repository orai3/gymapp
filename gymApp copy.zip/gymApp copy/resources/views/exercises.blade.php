<x-layout>
    <x-slot:heading>
        Exercise Library
    </x-slot:heading>

    <x-exercises-by-muscle-group />
</x-layout>
