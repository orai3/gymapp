<label {{ $attributes->merge(['class' => 'block text-sm font-medium leading-6 text-white-900']) }}>{{ $slot }}</label>
